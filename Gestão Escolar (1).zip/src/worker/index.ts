import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";

const app = new Hono<{ Bindings: Env }>();

// API Routes

// Get all classes
app.get("/api/classes", async (c) => {
  const classes = await c.env.DB.prepare(
    "SELECT * FROM classes ORDER BY created_at DESC"
  ).all();
  return c.json(classes.results);
});

// Get class with students, activities and grades
app.get("/api/classes/:id", async (c) => {
  const classId = c.req.param("id");
  
  const classData = await c.env.DB.prepare(
    "SELECT * FROM classes WHERE id = ?"
  ).bind(classId).first();
  
  if (!classData) {
    return c.json({ error: "Class not found" }, 404);
  }
  
  const students = await c.env.DB.prepare(
    "SELECT * FROM students WHERE class_id = ? ORDER BY number, name"
  ).bind(classId).all();
  
  const activities = await c.env.DB.prepare(
    "SELECT * FROM activities WHERE class_id = ? ORDER BY order_index, name"
  ).bind(classId).all();
  
  const grades = await c.env.DB.prepare(
    "SELECT * FROM grades WHERE activity_id IN (SELECT id FROM activities WHERE class_id = ?)"
  ).bind(classId).all();
  
  return c.json({
    class: classData,
    students: students.results,
    activities: activities.results,
    grades: grades.results,
  });
});

// Create new class
app.post(
  "/api/classes",
  zValidator(
    "json",
    z.object({
      name: z.string(),
      school_year: z.string().optional(),
    })
  ),
  async (c) => {
    const { name, school_year } = c.req.valid("json");
    
    const result = await c.env.DB.prepare(
      "INSERT INTO classes (name, school_year) VALUES (?, ?) RETURNING *"
    ).bind(name, school_year || null).first();
    
    return c.json(result);
  }
);

// Add student to class
app.post(
  "/api/students",
  zValidator(
    "json",
    z.object({
      class_id: z.number(),
      name: z.string(),
      status: z.string(),
      number: z.number().optional(),
      phone: z.string().optional(),
      profile_photo_url: z.string().optional(),
      life_project: z.string().optional(),
      youth_club_semester_1: z.string().optional(),
      youth_club_semester_2: z.string().optional(),
      elective_semester_1: z.string().optional(),
      elective_semester_2: z.string().optional(),
      tutor_teacher: z.string().optional(),
      guardian_1: z.string().optional(),
      guardian_2: z.string().optional(),
    })
  ),
  async (c) => {
    const data = c.req.valid("json");
    
    const result = await c.env.DB.prepare(
      `INSERT INTO students (
        class_id, name, status, number, phone, profile_photo_url, life_project,
        youth_club_semester_1, youth_club_semester_2, elective_semester_1,
        elective_semester_2, tutor_teacher, guardian_1, guardian_2
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(
      data.class_id, data.name, data.status, data.number || null,
      data.phone || null, data.profile_photo_url || null, data.life_project || null,
      data.youth_club_semester_1 || null, data.youth_club_semester_2 || null,
      data.elective_semester_1 || null, data.elective_semester_2 || null,
      data.tutor_teacher || null, data.guardian_1 || null, data.guardian_2 || null
    ).first();
    
    return c.json(result);
  }
);

// Update student
app.put(
  "/api/students/:id",
  zValidator(
    "json",
    z.object({
      name: z.string().optional(),
      status: z.string().optional(),
      number: z.number().optional(),
      phone: z.string().optional(),
      profile_photo_url: z.string().optional(),
      life_project: z.string().optional(),
      youth_club_semester_1: z.string().optional(),
      youth_club_semester_2: z.string().optional(),
      elective_semester_1: z.string().optional(),
      elective_semester_2: z.string().optional(),
      tutor_teacher: z.string().optional(),
      guardian_1: z.string().optional(),
      guardian_2: z.string().optional(),
    })
  ),
  async (c) => {
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    const updates = [];
    const values = [];
    
    const fieldMap = {
      name: "name",
      status: "status",
      number: "number",
      phone: "phone",
      profile_photo_url: "profile_photo_url",
      life_project: "life_project",
      youth_club_semester_1: "youth_club_semester_1",
      youth_club_semester_2: "youth_club_semester_2",
      elective_semester_1: "elective_semester_1",
      elective_semester_2: "elective_semester_2",
      tutor_teacher: "tutor_teacher",
      guardian_1: "guardian_1",
      guardian_2: "guardian_2",
    };
    
    for (const [key, column] of Object.entries(fieldMap)) {
      if (data[key as keyof typeof data] !== undefined) {
        updates.push(`${column} = ?`);
        values.push(data[key as keyof typeof data]);
      }
    }
    
    values.push(id);
    
    await c.env.DB.prepare(
      `UPDATE students SET ${updates.join(", ")}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
    ).bind(...values).run();
    
    const result = await c.env.DB.prepare(
      "SELECT * FROM students WHERE id = ?"
    ).bind(id).first();
    
    return c.json(result);
  }
);

// Delete student
app.delete("/api/students/:id", async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare("DELETE FROM grades WHERE student_id = ?").bind(id).run();
  await c.env.DB.prepare("DELETE FROM students WHERE id = ?").bind(id).run();
  
  return c.json({ success: true });
});

// Add activity to class
app.post(
  "/api/activities",
  zValidator(
    "json",
    z.object({
      class_id: z.number(),
      name: z.string(),
      max_score: z.number(),
      weight: z.number().optional(),
      order_index: z.number().optional(),
    })
  ),
  async (c) => {
    const { class_id, name, max_score, weight, order_index } = c.req.valid("json");
    
    const result = await c.env.DB.prepare(
      "INSERT INTO activities (class_id, name, max_score, weight, order_index) VALUES (?, ?, ?, ?, ?) RETURNING *"
    ).bind(class_id, name, max_score, weight || 1, order_index || null).first();
    
    return c.json(result);
  }
);

// Update activity
app.put(
  "/api/activities/:id",
  zValidator(
    "json",
    z.object({
      name: z.string().optional(),
      max_score: z.number().optional(),
      weight: z.number().optional(),
      order_index: z.number().optional(),
    })
  ),
  async (c) => {
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    const updates = [];
    const values = [];
    
    if (data.name !== undefined) {
      updates.push("name = ?");
      values.push(data.name);
    }
    if (data.max_score !== undefined) {
      updates.push("max_score = ?");
      values.push(data.max_score);
    }
    if (data.weight !== undefined) {
      updates.push("weight = ?");
      values.push(data.weight);
    }
    if (data.order_index !== undefined) {
      updates.push("order_index = ?");
      values.push(data.order_index);
    }
    
    values.push(id);
    
    await c.env.DB.prepare(
      `UPDATE activities SET ${updates.join(", ")}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
    ).bind(...values).run();
    
    const result = await c.env.DB.prepare(
      "SELECT * FROM activities WHERE id = ?"
    ).bind(id).first();
    
    return c.json(result);
  }
);

// Delete activity
app.delete("/api/activities/:id", async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare("DELETE FROM grades WHERE activity_id = ?").bind(id).run();
  await c.env.DB.prepare("DELETE FROM activities WHERE id = ?").bind(id).run();
  
  return c.json({ success: true });
});

// Set or update grade
app.post(
  "/api/grades",
  zValidator(
    "json",
    z.object({
      student_id: z.number(),
      activity_id: z.number(),
      score: z.number().nullable(),
    })
  ),
  async (c) => {
    const { student_id, activity_id, score } = c.req.valid("json");
    
    const existing = await c.env.DB.prepare(
      "SELECT id FROM grades WHERE student_id = ? AND activity_id = ?"
    ).bind(student_id, activity_id).first();
    
    let result;
    if (existing) {
      await c.env.DB.prepare(
        "UPDATE grades SET score = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(score, existing.id).run();
      
      result = await c.env.DB.prepare(
        "SELECT * FROM grades WHERE id = ?"
      ).bind(existing.id).first();
    } else {
      result = await c.env.DB.prepare(
        "INSERT INTO grades (student_id, activity_id, score) VALUES (?, ?, ?) RETURNING *"
      ).bind(student_id, activity_id, score).first();
    }
    
    return c.json(result);
  }
);

// Upload profile photo
app.post("/api/students/:id/photo", async (c) => {
  const id = c.req.param("id");
  const formData = await c.req.formData();
  const file = formData.get("photo") as File;
  
  if (!file) {
    return c.json({ error: "No file provided" }, 400);
  }
  
  // Validate file type
  const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"];
  if (!allowedTypes.includes(file.type)) {
    return c.json({ error: "Invalid file type. Only images are allowed." }, 400);
  }
  
  // Validate file size (max 5MB)
  if (file.size > 5 * 1024 * 1024) {
    return c.json({ error: "File too large. Maximum size is 5MB." }, 400);
  }
  
  const extension = file.name.split(".").pop() || "jpg";
  const key = `students/${id}/profile.${extension}`;
  
  // Upload to R2
  await c.env.R2_BUCKET.put(key, file.stream(), {
    httpMetadata: {
      contentType: file.type,
    },
  });
  
  const photoUrl = `/api/files/${key}`;
  
  // Update student record
  await c.env.DB.prepare(
    "UPDATE students SET profile_photo_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(photoUrl, id).run();
  
  return c.json({ url: photoUrl });
});

// Get file from R2
app.get("/api/files/*", async (c) => {
  const key = c.req.path.replace("/api/files/", "");
  
  const object = await c.env.R2_BUCKET.get(key);
  
  if (!object) {
    return c.json({ error: "File not found" }, 404);
  }
  
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("cache-control", "public, max-age=31536000");
  
  return c.body(object.body, { headers });
});

export default app;
