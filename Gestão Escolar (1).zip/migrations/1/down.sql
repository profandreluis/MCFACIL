
DROP INDEX idx_grades_activity_id;
DROP INDEX idx_grades_student_id;
DROP TABLE grades;
DROP INDEX idx_activities_class_id;
DROP TABLE activities;
DROP INDEX idx_students_class_id;
DROP TABLE students;
DROP TABLE classes;
