
ALTER TABLE students ADD COLUMN phone TEXT;
ALTER TABLE students ADD COLUMN profile_photo_url TEXT;
ALTER TABLE students ADD COLUMN life_project TEXT;
ALTER TABLE students ADD COLUMN youth_club_semester_1 TEXT;
ALTER TABLE students ADD COLUMN youth_club_semester_2 TEXT;
ALTER TABLE students ADD COLUMN elective_semester_1 TEXT;
ALTER TABLE students ADD COLUMN elective_semester_2 TEXT;
ALTER TABLE students ADD COLUMN tutor_teacher TEXT;
ALTER TABLE students ADD COLUMN guardian_1 TEXT;
ALTER TABLE students ADD COLUMN guardian_2 TEXT;
