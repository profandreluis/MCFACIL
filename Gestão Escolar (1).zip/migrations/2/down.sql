
ALTER TABLE students DROP COLUMN guardian_2;
ALTER TABLE students DROP COLUMN guardian_1;
ALTER TABLE students DROP COLUMN tutor_teacher;
ALTER TABLE students DROP COLUMN elective_semester_2;
ALTER TABLE students DROP COLUMN elective_semester_1;
ALTER TABLE students DROP COLUMN youth_club_semester_2;
ALTER TABLE students DROP COLUMN youth_club_semester_1;
ALTER TABLE students DROP COLUMN life_project;
ALTER TABLE students DROP COLUMN profile_photo_url;
ALTER TABLE students DROP COLUMN phone;
